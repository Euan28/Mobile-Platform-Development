// Name: Euan Martin
// Matriculation Number: S1705053

package org.me.gcu.equakestartercode.parser;

import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;

import org.me.gcu.equakestartercode.models.EarthquakeModel;

public class XMLParser {
    int event;
    private String url ="http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";
    public static EarthquakeModel earthquake;
    public static ArrayList<EarthquakeModel> earthquakes;

    public void parseXML(Executor executor, Runnable callback)
    {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                parseXMLInternal();

                callback.run();
            }
        });
    }

    private void parseXMLInternal() {

        try {
            URL urlXMLEq = new URL(url);
            XmlPullParserFactory factoryXML = XmlPullParserFactory.newInstance();
            factoryXML.setNamespaceAware(false);
            XmlPullParser xppeq = factoryXML.newPullParser();
            xppeq.setInput(getInputStream(urlXMLEq), "UTF_8");
            event = xppeq.getEventType();
            earthquake = null;
            earthquakes = null;
            boolean isItem;
            try {
                isItem = false;
                while (event != XmlPullParser.END_DOCUMENT) {
                    if (event == XmlPullParser.END_TAG) {
                        if (xppeq.getName().equalsIgnoreCase("item")) {
                            earthquakes.add(earthquake);
                        } else if (xppeq.getName().equalsIgnoreCase("channel")) {
                            Log.e("Tag", "Channel tag");
                        }
                    } else if (event == XmlPullParser.START_TAG) {
                        if (xppeq.getName().equalsIgnoreCase("channel")) {
                            earthquakes = new ArrayList<EarthquakeModel>();
                        } else if (xppeq.getName().equalsIgnoreCase("item")) {
                            earthquake = new EarthquakeModel();
                            isItem = true;
                        } else if (xppeq.getName().equalsIgnoreCase("description") && isItem == true) {
                            String eDescription = xppeq.nextText();
                            String[] e = eDescription.split(";");
                            String[] date = e[0].split(":", 2);
                            String eDate = date[1].trim();
                            String[] location = e[1].split(":");
                            String eLocation = location[1].trim();
                            String[] latandlon = e[2].split(":");
                            String[] latLon = latandlon[1].split(",");
                            String eLatitude = latLon[0].trim();
                            String eLongtitude = latLon[1].trim();
                            String[] depth = e[3].split(":");
                            String eDepth = depth[1].trim();
                            String[] magnitude = e[4].split(":");
                            String eMagnitude = magnitude[1].trim();

                            earthquake.setEarthquakeTitle(eLocation);
                            earthquake.setEarthquakePubDate(eDate);
                            earthquake.setEarthquakeGeo_lat(eLatitude);
                            earthquake.setEarthquakeGeo_long(eLongtitude);
                            earthquake.setEarthquakeDepth(eDepth);
                            earthquake.setEarthquakeMagnitude(eMagnitude);
                        }
                    }
                    event = xppeq.next();
                }
            } catch (XmlPullParserException e) {
                Log.e("XmlPullParserException", "XmlPullParserException");
            } catch (IOException e) {
                Log.e("IOException", "IOException");
            }
        } catch (MalformedURLException | XmlPullParserException e) {
            e.printStackTrace();
        }
        return;
    }

    public InputStream getInputStream(URL url){
        try {
            return url.openConnection().getInputStream();
        }
        catch (IOException e) {
            return null;
        }
    }

    public static ArrayList<EarthquakeModel> getEarthquakes()
    {
        return earthquakes;
    }
}


