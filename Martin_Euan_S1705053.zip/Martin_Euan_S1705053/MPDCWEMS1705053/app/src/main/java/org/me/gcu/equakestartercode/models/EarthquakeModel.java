// Name: Euan Martin
// Matriculation Number: S1705053

package org.me.gcu.equakestartercode.models;

import java.io.Serializable;

public class EarthquakeModel implements Serializable { // earthquake class
    public String earthquakeTitle; // earthquake title
    public String earthquakeDescription; // earthquake desc
    public String earthquakePubDate; // earthquake pub date
    public String earthquakeGeo_long; // earthquake get long
    public String earthquakeGeo_lat; // earthquake geo lat
    public String earthquakeCategory; // earthquake cate
    public String earthquakeDepth; // earthquake depth
    public String earthquakeMagnitude; // earthquake mag

    public EarthquakeModel(String atitle, String description, String pubDate, String category, String geo_lat, String geo_long, String depth, String mag) // attr
    {
        this.earthquakeTitle = atitle; // assigning earthquake title
        this.earthquakeDescription = description; // earthquake desc
        this.earthquakePubDate = pubDate; // earthquake pub date
        this.earthquakeGeo_long = geo_long; // earthquake geo long
        this.earthquakeGeo_lat = geo_lat; // earthquake geo lat
        this.earthquakeCategory = category; // earthquake cate
        this.earthquakeDepth = depth; // earthquake depth
        this.earthquakeMagnitude = mag; // earthquake mag
    }

    public EarthquakeModel()
    {
        earthquakeTitle = getEarthquakeTitle(); // earthquake title
        earthquakeDescription = getEarthquakeDescription(); // earthquake desc
        earthquakePubDate = ""; // earthquake pub date
        earthquakeGeo_long = ""; // earthquake get long
        earthquakeGeo_lat = ""; // earthquake geo lat
        earthquakeCategory = ""; // earthquake cate
        earthquakeDepth = ""; // earthquake depth
        earthquakeMagnitude = ""; // earthquake mag
    }

    // get methods

    public String getEarthquakeTitle() { // return earthquake title
        return earthquakeTitle;
    }
    public String getEarthquakeDescription() { // return earthquake desc
        return earthquakeDescription;
    }
    public String getEarthquakePubDate() { // return earthquake pub date
        return earthquakePubDate;
    }
    public String getEarthquakeCategory() { // return earthquake cate
        return earthquakeCategory;
    }
    public String getEarthquakeGeo_lat() { // return earthquake lat
        return earthquakeGeo_lat;
    }
    public String getEarthquakeGeo_long() { // return earthquake long
        return earthquakeGeo_long;
    }
    public String getEarthquakeDepth() { return earthquakeDepth; }
    public String getEarthquakeMagnitude() {return  earthquakeMagnitude;}

    // set methods
    public void setEarthquakeTitle(String title) {
        earthquakeTitle = title;
    }

    public void setEarthquakeDescription(String description) {
        earthquakeDescription = description;
    }

    public void setEarthquakePubDate(String date) {
        earthquakePubDate = date;
    }

    public void setEarthquakeCategory(String category) {
        earthquakeCategory = category;
    }

    public void setEarthquakeGeo_lat(String lat) {
        earthquakeGeo_lat = lat;
    }

    public void setEarthquakeGeo_long(String lon) {
        earthquakeGeo_long = lon;
    }

    public void setEarthquakeDepth(String depth) { earthquakeDepth = depth; }

    public void setEarthquakeMagnitude(String m){
        earthquakeMagnitude=m;
    }

    @Override
    public String toString() {
        return "Earthquake{" + "title= " + earthquakeTitle + ", date='" + earthquakePubDate + '}';
    }
}
