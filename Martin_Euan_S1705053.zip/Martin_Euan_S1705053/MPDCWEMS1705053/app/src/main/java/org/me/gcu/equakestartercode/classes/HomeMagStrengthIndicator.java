// Name: Euan Martin
// Matriculation Number: S1705053

package org.me.gcu.equakestartercode.classes;

public class HomeMagStrengthIndicator {

    public double magStrength;

    public HomeMagStrengthIndicator(double magStrength) {
        this.magStrength = magStrength;
    }

    public String GetMagStrength() {

        String magColour;

        if(magStrength >=2.5){
            magColour = "#B90E0A";
        } else if(magStrength >=1.5){
            magColour = "#FCE205";
        } else{
            magColour = "#028A0F";
        }
        return magColour;
    }
}
