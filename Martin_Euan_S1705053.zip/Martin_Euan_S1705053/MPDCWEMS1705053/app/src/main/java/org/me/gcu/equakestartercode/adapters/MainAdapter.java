// Name: Euan Martin
// Matriculation Number: S1705053

package org.me.gcu.equakestartercode.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.me.gcu.equakestartercode.models.EarthquakeModel;
import org.me.gcu.equakestartercode.R;


import java.util.ArrayList;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.HolderStat> {

    private Context context;
    private ArrayList<EarthquakeModel> earthquakeModelArrayList;

    public MainAdapter(Context context, ArrayList<EarthquakeModel> earthquakeModelArrayList) {
        this.context = context;
        this.earthquakeModelArrayList = earthquakeModelArrayList;
    }

    @NonNull
    @Override
    public HolderStat onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // inflate layout row_data.xml
        View view = LayoutInflater.from(context).inflate(R.layout.row_data, parent, false);

        return new HolderStat(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderStat holder, int position) {

        // get data
        EarthquakeModel earthquakeModel = earthquakeModelArrayList.get(position);

        String title = earthquakeModel.getEarthquakeTitle();
        String date = earthquakeModel.getEarthquakePubDate();
        String mag = earthquakeModel.getEarthquakeMagnitude();

        // set data
        holder.titleEarthquakeTxt.setText(title);
        holder.dateEarthquake.setText(date);
        holder.magnitudeEarthquakeTxt.setText(mag);
    }

    @Override
    public int getItemCount() {
        return earthquakeModelArrayList.size();
    }

    // view holder class
    class HolderStat extends RecyclerView.ViewHolder{

        // UI views
        TextView titleEarthquakeTxt, dateEarthquake, depthEarthquakeTxt, magnitudeEarthquakeTxt;

        public HolderStat(@NonNull View itemView) {
            super(itemView);

            //init UI views
            titleEarthquakeTxt = itemView.findViewById(R.id.titleEarthquakeTxt);
            dateEarthquake = itemView.findViewById(R.id.dateEarthquake);
            depthEarthquakeTxt = itemView.findViewById(R.id.depthEarthquakeTxt);
            magnitudeEarthquakeTxt = itemView.findViewById(R.id.magnitudeEarthquakeTxt);

        }
    }
}
