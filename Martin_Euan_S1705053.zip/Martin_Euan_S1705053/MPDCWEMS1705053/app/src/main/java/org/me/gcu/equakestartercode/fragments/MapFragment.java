// Name: Euan Martin
// Matriculation Number: S1705053

package org.me.gcu.equakestartercode.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.me.gcu.equakestartercode.R;
import org.me.gcu.equakestartercode.classes.MapMagStrengthIndicator;
import org.me.gcu.equakestartercode.models.EarthquakeModel;
import org.me.gcu.equakestartercode.parser.XMLParser;

import java.util.ArrayList;

public class MapFragment extends Fragment implements OnMapReadyCallback {

    // context
    Context context;

    GoogleMap map;
    private SupportMapFragment mMap;

    public MapFragment() {
        // required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_map, container, false);


        SupportMapFragment mapFragment = (SupportMapFragment)getChildFragmentManager().findFragmentById(R.id.map);
        System.out.println("Map Fragment " + mapFragment);
        mapFragment.getMapAsync(this);

        return view;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;

        ArrayList<EarthquakeModel> earthquakeMapData = XMLParser.getEarthquakes();

        for (EarthquakeModel earthquakemapvar : earthquakeMapData) {

            MapMagStrengthIndicator mapMagStrengthIndicator = new MapMagStrengthIndicator(Double.parseDouble(earthquakemapvar.getEarthquakeMagnitude()));

            double maplat = Double.parseDouble(earthquakemapvar.getEarthquakeGeo_lat());
            double maplong = Double.parseDouble(earthquakemapvar.getEarthquakeGeo_long());
            LatLng location = new LatLng(maplat, maplong);
            map.addMarker(new MarkerOptions().position(location).title(earthquakemapvar.getEarthquakeTitle()).icon(BitmapDescriptorFactory.fromResource(mapMagStrengthIndicator.GetStrength())).snippet("Magnitude: " + earthquakemapvar.getEarthquakeMagnitude()));
            CameraPosition cameraPosition = new CameraPosition.Builder().target(location).zoom(4).build();
            CameraUpdate cameraUpdate = CameraUpdateFactory.newCameraPosition(cameraPosition);
            map.moveCamera(cameraUpdate);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}