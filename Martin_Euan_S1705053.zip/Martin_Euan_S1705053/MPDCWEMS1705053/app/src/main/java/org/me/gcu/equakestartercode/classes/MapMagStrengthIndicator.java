// Name: Euan Martin
// Matriculation Number: S1705053

package org.me.gcu.equakestartercode.classes;

import org.me.gcu.equakestartercode.R;

public class MapMagStrengthIndicator {

    public double mapMag;

    public MapMagStrengthIndicator(double mapMag) {
        this.mapMag = mapMag;
    }

    public int GetStrength() {

        int strength;

        if (mapMag >= 0 && mapMag < 1.5) {
            strength = R.drawable.green_marker;
        } else if (mapMag >= 1.5 && mapMag < 2.5) {
            strength = R.drawable.yellow_marker;
        } else {
            strength = R.drawable.red_marker;
        }
        return strength;
    }
}
