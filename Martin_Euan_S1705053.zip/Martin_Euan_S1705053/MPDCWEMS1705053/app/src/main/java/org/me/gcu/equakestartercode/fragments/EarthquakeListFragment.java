// Name: Euan Martin
// Matriculation Number: S1705053

package org.me.gcu.equakestartercode.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.me.gcu.equakestartercode.adapters.EarthquakeRecyclerViewAdapter;
import org.me.gcu.equakestartercode.R;
import org.me.gcu.equakestartercode.models.EarthquakeModel;
import org.me.gcu.equakestartercode.parser.XMLParser;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EarthquakeListFragment extends Fragment
{
    // context for fragments
    Context context;

    // store parsed data
    ArrayList<EarthquakeModel> earthquakeData = new ArrayList<EarthquakeModel>();

    XMLParser xmlParser;

    // gets us a new thread for network activity
    ExecutorService executorService = Executors.newSingleThreadExecutor();

    EarthquakeRecyclerViewAdapter adapter;
    RecyclerView list;
    public EarthquakeListFragment()
    {
        xmlParser = new XMLParser();
        xmlParser.parseXML(executorService, new Runnable() {
            @Override
            public void run() {
                onPopulateData();
            }
        });
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // inflate the layout for this fragment
        View view = inflater.inflate(R.layout.earthquake_list_fragment, container, false);

        //get the list from the XML
        list = view.findViewById(R.id.earthquakeList);
        list.setLayoutManager(new LinearLayoutManager(context));

        //adapter handles the list data
        adapter = new EarthquakeRecyclerViewAdapter(context, earthquakeData);
        list.setAdapter(adapter);

        fillList();

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    private void onPopulateData()
    {
        earthquakeData = xmlParser.getEarthquakes();
        fillList();
    }

    private void fillList()
    {
        if(adapter != null)
        {
            // refresh the list data
            adapter.notifyDataSetChanged();
            adapter.setData(earthquakeData);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}

