// Name: Euan Martin
// Matriculation Number: S1705053

package org.me.gcu.equakestartercode;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import org.me.gcu.equakestartercode.R;

import org.me.gcu.equakestartercode.fragments.EarthquakeListFragment;
import org.me.gcu.equakestartercode.fragments.HomeFragment;
import org.me.gcu.equakestartercode.fragments.StatsFragment;
import org.me.gcu.equakestartercode.fragments.MapFragment;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    private TextView rawDataDisplay;
    private Button startButton;
    private String result = "";
    private String url1="";
    private String urlSource="http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";


    // UI Views
    private TextView titleTv;
    private ImageButton refreshBtn;
    private BottomNavigationView navigationView;

    // fragments
    private Fragment homeFragment, statsFragment, mapFragment, earthquakeListFragment;
    private Fragment activeFragment;
    private FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //init UI Views
        titleTv = findViewById(R.id.titleTv);
        refreshBtn = findViewById(R.id.refreshBtn);
        navigationView = findViewById(R.id.navigationView);

        initFragments();

        // refresh button clicks, refresh records
        refreshBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        navigationView.setOnNavigationItemSelectedListener(this);
    }

    private void initFragments() {
        // init fragments
        homeFragment = new HomeFragment();
        statsFragment = new StatsFragment();
        mapFragment = new MapFragment();
        earthquakeListFragment = new EarthquakeListFragment();

        fragmentManager = getSupportFragmentManager();
        activeFragment = homeFragment;

        fragmentManager.beginTransaction()
                .add(R.id.frame, homeFragment, "homeFragment")
                .commit();
        fragmentManager.beginTransaction()
                .add(R.id.frame, statsFragment, "statsFragment")
                .hide(statsFragment)
                .commit();
        fragmentManager.beginTransaction()
                .add(R.id.frame, mapFragment, "mapFragment")
                .hide(mapFragment)
                .commit();
        fragmentManager.beginTransaction()
                .add(R.id.frame, earthquakeListFragment, "eqFrag")
                .hide(earthquakeListFragment)
                .commit();
    }

    private void loadHomeFragment(){
        titleTv.setText("Home - RSS Feed");
        fragmentManager.beginTransaction().setReorderingAllowed(true).hide(activeFragment).show(homeFragment).commit();
        activeFragment = homeFragment;

        fragmentManager.beginTransaction().setReorderingAllowed(true).show(earthquakeListFragment).commit();
    }

    private void loadStatsFragment(){
        titleTv.setText("Statistics");
        fragmentManager.beginTransaction().setReorderingAllowed(true).hide(activeFragment).show(statsFragment).commit();
        activeFragment = statsFragment;
    }

    private void loadMapFragment(){
        titleTv.setText("Map");
        fragmentManager.beginTransaction().setReorderingAllowed(true).hide(activeFragment).show(mapFragment).commit();
        activeFragment = mapFragment;
    }

    private void loadEarthquakeListFragment(){
        titleTv.setText("Home - RSS Feed");
        fragmentManager.beginTransaction().setReorderingAllowed(true).hide(activeFragment).show(earthquakeListFragment).commit();
        activeFragment = earthquakeListFragment;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // handle bottom nav item clicks
        switch (item.getItemId()){
            case R.id.nav_eq2:
                loadHomeFragment();
                return true;
            case R.id.nav_stats:
                loadStatsFragment();
                return true;
            case R.id.nav_map:
                loadMapFragment();
                return true;
            case R.id.nav_eq:
                loadEarthquakeListFragment();
                return true;
        }
        return false;
    }
}
