// Name: Euan Martin
// Matriculation Number: S1705053

package org.me.gcu.equakestartercode.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import org.me.gcu.equakestartercode.classes.HomeMagStrengthIndicator;
import org.me.gcu.equakestartercode.models.EarthquakeModel;
import org.me.gcu.equakestartercode.R;
import org.me.gcu.equakestartercode.classes.MapMagStrengthIndicator;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EarthquakeRecyclerViewAdapter extends RecyclerView.Adapter<EarthquakeRecyclerViewAdapter.ViewHolder>
{
    private List<EarthquakeModel> earthquakeList;
    private LayoutInflater eqLayoutIn;
    private ItemClickListener eqItemClLi;

    public EarthquakeRecyclerViewAdapter(Context context, List<EarthquakeModel> eqList) {
        this.eqLayoutIn = LayoutInflater.from(context);
        this.earthquakeList = eqList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = eqLayoutIn.inflate(R.layout.earthquake_list_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        String text = earthquakeList.get(position).earthquakeTitle;
        String date = earthquakeList.get(position).earthquakePubDate;
        String geoLong = earthquakeList.get(position).earthquakeGeo_long;
        String geoLat = earthquakeList.get(position).earthquakeGeo_lat;
        String depth = earthquakeList.get(position).earthquakeDepth;
        String mag = earthquakeList.get(position).earthquakeMagnitude;
        String magstrength = earthquakeList.get(position).earthquakeMagnitude;

        holder.titleLabel.setText(text);
        holder.pubdateLabel.setText(date);
        holder.geolongLabel.setText(geoLong);
        holder.geolatLabel.setText(geoLat);
        holder.depthLabel.setText(depth);
        holder.magLabel.setText(mag);
        holder.magstrengthLabel.setText(magstrength);

        HomeMagStrengthIndicator homeMagStrengthIndicator =  new HomeMagStrengthIndicator(Double.parseDouble(magstrength));

        holder.magstrengthLabel.setTextColor(Color.parseColor(homeMagStrengthIndicator.GetMagStrength()));
        holder.magstrengthLabel.setText("◉");
        holder.magstrengthLabel.setTextSize(75);
    }

    @Override
    public int getItemCount() {
        return earthquakeList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView titleLabel;
        TextView pubdateLabel;
        TextView geolongLabel;
        TextView geolatLabel;
        TextView depthLabel;
        TextView magLabel;
        TextView magstrengthLabel;

        ViewHolder(View itemView) {
            super(itemView);
            titleLabel = itemView.findViewById(R.id.earthquakeName);
            pubdateLabel = itemView.findViewById(R.id.earthquakePubDate);
            geolongLabel = itemView.findViewById(R.id.earthquakeGeoLong);
            geolatLabel = itemView.findViewById(R.id.earthquakeGeoLat);
            depthLabel = itemView.findViewById(R.id.earthquakeDepth);
            magLabel = itemView.findViewById(R.id.earthquakeMagnitude);
            magstrengthLabel = itemView.findViewById(R.id.earthquakeStrength);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (eqItemClLi != null) eqItemClLi.onItemClick(view, getAdapterPosition());
        }
    }

    EarthquakeModel getItem(int id) {
        return earthquakeList.get(id);
    }

    public void setData(ArrayList<EarthquakeModel> updatedEarthquakeList)
    {
        earthquakeList = updatedEarthquakeList;
        notifyDataSetChanged();
    }

    void setClickListener(ItemClickListener itemClickListener) {
        this.eqItemClLi = itemClickListener;
    }

    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }
}
